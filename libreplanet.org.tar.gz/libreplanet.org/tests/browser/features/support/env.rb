require 'mediawiki_selenium'

require 'mediawiki_selenium/support'
require 'mediawiki_selenium/step_definitions'
