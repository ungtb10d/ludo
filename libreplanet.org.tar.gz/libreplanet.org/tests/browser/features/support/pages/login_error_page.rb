class LoginErrorPage
  include PageObject

  div(:error_box, class: 'errorbox')
end
