<?php

class TestAutoloadedCamlClass {
}
