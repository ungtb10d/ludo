<?php

$result = array();
