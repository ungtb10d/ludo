<?php

$result = array( 'xmp-exif' =>
	array(
		'DigitalZoomRatio' => '0/10',
		'Flash' => '127'
	)
);
